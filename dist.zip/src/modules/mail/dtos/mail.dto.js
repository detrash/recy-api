"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MailDto = void 0;
const openapi = require("@nestjs/swagger");
class MailDto {
    static _OPENAPI_METADATA_FACTORY() {
        return { from: { required: true, type: () => String }, to: { required: true, type: () => String }, subject: { required: true, type: () => String }, html: { required: false, type: () => String }, react: { required: true, type: () => Object } };
    }
}
exports.MailDto = MailDto;
//# sourceMappingURL=mail.dto.js.map