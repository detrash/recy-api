import { MailDto } from './dtos/mail.dto';
export declare class MailService {
    private resend;
    constructor();
    sendEmail(mail: MailDto): Promise<import("resend").CreateEmailResponse>;
}
