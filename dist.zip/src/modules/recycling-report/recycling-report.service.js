"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RecyclingReportService = void 0;
const common_1 = require("@nestjs/common");
const ulid_1 = require("ulid");
const prisma_service_1 = require("../prisma/prisma.service");
let RecyclingReportService = class RecyclingReportService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    async checkUserExists(userId) {
        const user = await this.prisma.user.findUnique({
            where: { id: userId },
        });
        if (!user) {
            throw new common_1.NotFoundException(`User with ID ${userId} not found.`);
        }
        return user;
    }
    async createRecyclingReport(createRecyclingReportDto) {
        const { submittedBy, reportDate, phone, materials, walletAddress, evidenceUrl, } = createRecyclingReportDto;
        await this.checkUserExists(submittedBy);
        const jsonMaterials = materials;
        const reportId = (0, ulid_1.ulid)();
        return this.prisma.recyclingReport.create({
            data: {
                id: reportId,
                submittedBy: submittedBy,
                reportDate,
                audited: false,
                phone,
                materials: jsonMaterials,
                walletAddress,
                evidenceUrl,
            },
        });
    }
    async findAllRecyclingReports() {
        return this.prisma.recyclingReport.findMany({
            include: { user: true, audits: true },
        });
    }
    async findRecyclingReportById(id) {
        const report = await this.prisma.recyclingReport.findUnique({
            where: { id },
            include: { user: true, audits: true },
        });
        if (!report) {
            throw new common_1.NotFoundException(`RecyclingReport with ID ${id} not found.`);
        }
        return report;
    }
    async findRecyclingReportsByUser(userId) {
        await this.checkUserExists(userId);
        return this.prisma.recyclingReport.findMany({
            where: { submittedBy: userId },
            include: { user: true, audits: true },
        });
    }
    async updateRecyclingReport(id, updateRecyclingReportDto) {
        const { materials, submittedBy } = updateRecyclingReportDto;
        const existingReport = await this.prisma.recyclingReport.findUnique({
            where: { id },
        });
        if (!existingReport) {
            throw new common_1.NotFoundException(`RecyclingReport with ID ${id} not found.`);
        }
        if (submittedBy) {
            await this.checkUserExists(submittedBy);
        }
        const jsonMaterials = materials;
        return this.prisma.recyclingReport.update({
            where: { id },
            data: Object.assign(Object.assign({}, updateRecyclingReportDto), { materials: jsonMaterials }),
        });
    }
    async deleteRecyclingReport(id) {
        const existingReport = await this.prisma.recyclingReport.findUnique({
            where: { id },
        });
        if (!existingReport) {
            throw new common_1.NotFoundException(`RecyclingReport with ID ${id} not found.`);
        }
        return this.prisma.recyclingReport.delete({
            where: { id },
        });
    }
};
exports.RecyclingReportService = RecyclingReportService;
exports.RecyclingReportService = RecyclingReportService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], RecyclingReportService);
//# sourceMappingURL=recycling-report.service.js.map