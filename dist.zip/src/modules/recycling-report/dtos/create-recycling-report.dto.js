"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaterialDto = exports.CreateRecyclingReportDto = void 0;
const openapi = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
const residue_type_enum_1 = require("./residue-type.enum");
class CreateRecyclingReportDto {
    static _OPENAPI_METADATA_FACTORY() {
        return { submittedBy: { required: true, type: () => String }, reportDate: { required: true, type: () => Date }, phone: { required: false, type: () => String }, materials: { required: true, type: () => [require("./create-recycling-report.dto").MaterialDto] }, walletAddress: { required: false, type: () => String }, evidenceUrl: { required: true, type: () => String } };
    }
}
exports.CreateRecyclingReportDto = CreateRecyclingReportDto;
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", String)
], CreateRecyclingReportDto.prototype, "submittedBy", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_transformer_1.Type)(() => Date),
    __metadata("design:type", Date)
], CreateRecyclingReportDto.prototype, "reportDate", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateRecyclingReportDto.prototype, "phone", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => MaterialDto),
    __metadata("design:type", Array)
], CreateRecyclingReportDto.prototype, "materials", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateRecyclingReportDto.prototype, "walletAddress", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateRecyclingReportDto.prototype, "evidenceUrl", void 0);
class MaterialDto {
    static _OPENAPI_METADATA_FACTORY() {
        return { materialType: { required: true, enum: require("./residue-type.enum").ResidueType }, weightKg: { required: true, type: () => Number } };
    }
}
exports.MaterialDto = MaterialDto;
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsEnum)(residue_type_enum_1.ResidueType),
    __metadata("design:type", String)
], MaterialDto.prototype, "materialType", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], MaterialDto.prototype, "weightKg", void 0);
//# sourceMappingURL=create-recycling-report.dto.js.map