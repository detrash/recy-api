"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateRecyclingReportDto = void 0;
const openapi = require("@nestjs/swagger");
const mapped_types_1 = require("@nestjs/mapped-types");
const create_recycling_report_dto_1 = require("./create-recycling-report.dto");
class UpdateRecyclingReportDto extends (0, mapped_types_1.PartialType)(create_recycling_report_dto_1.CreateRecyclingReportDto) {
    static _OPENAPI_METADATA_FACTORY() {
        return {};
    }
}
exports.UpdateRecyclingReportDto = UpdateRecyclingReportDto;
//# sourceMappingURL=update-recycling-report.dto.js.map