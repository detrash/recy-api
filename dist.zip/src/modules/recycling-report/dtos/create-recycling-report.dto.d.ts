import { ResidueType } from './residue-type.enum';
export declare class CreateRecyclingReportDto {
    submittedBy: string;
    reportDate: Date;
    phone?: string;
    materials: MaterialDto[];
    walletAddress?: string;
    evidenceUrl: string;
}
export declare class MaterialDto {
    materialType: ResidueType;
    weightKg: number;
}
