import { CreateRecyclingReportDto } from './create-recycling-report.dto';
declare const UpdateRecyclingReportDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateRecyclingReportDto>>;
export declare class UpdateRecyclingReportDto extends UpdateRecyclingReportDto_base {
}
export {};
