"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResidueType = void 0;
var ResidueType;
(function (ResidueType) {
    ResidueType["GLASS"] = "GLASS";
    ResidueType["METAL"] = "METAL";
    ResidueType["ORGANIC"] = "ORGANIC";
    ResidueType["PAPER"] = "PAPER";
    ResidueType["PLASTIC"] = "PLASTIC";
    ResidueType["TEXTILE"] = "TEXTILE";
    ResidueType["LANDFILL_WASTE"] = "LANDFILL_WASTE";
})(ResidueType || (exports.ResidueType = ResidueType = {}));
//# sourceMappingURL=residue-type.enum.js.map