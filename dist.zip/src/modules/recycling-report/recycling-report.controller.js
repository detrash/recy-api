"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RecyclingReportController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const create_recycling_report_dto_1 = require("./dtos/create-recycling-report.dto");
const update_recycling_report_dto_1 = require("./dtos/update-recycling-report.dto");
const recycling_report_service_1 = require("./recycling-report.service");
let RecyclingReportController = class RecyclingReportController {
    constructor(recyclingReportService) {
        this.recyclingReportService = recyclingReportService;
    }
    async createRecyclingReport(createRecyclingReportDto) {
        return this.recyclingReportService.createRecyclingReport(createRecyclingReportDto);
    }
    async findAllRecyclingReports() {
        return this.recyclingReportService.findAllRecyclingReports();
    }
    async findRecyclingReportById(id) {
        return this.recyclingReportService.findRecyclingReportById(id);
    }
    async updateRecyclingReport(id, updateRecyclingReportDto) {
        return this.recyclingReportService.updateRecyclingReport(id, updateRecyclingReportDto);
    }
    async deleteRecyclingReport(id) {
        return this.recyclingReportService.deleteRecyclingReport(id);
    }
};
exports.RecyclingReportController = RecyclingReportController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Create a new recycling report' }),
    (0, swagger_1.ApiResponse)({
        status: 201,
        description: 'The recycling report has been successfully created.',
    }),
    (0, swagger_1.ApiResponse)({
        status: 400,
        description: 'Bad request. Validation errors or other issues.',
    }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_recycling_report_dto_1.CreateRecyclingReportDto]),
    __metadata("design:returntype", Promise)
], RecyclingReportController.prototype, "createRecyclingReport", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Retrieve all recycling reports' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'List of recycling reports.',
    }),
    openapi.ApiResponse({ status: 200 }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], RecyclingReportController.prototype, "findAllRecyclingReports", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Retrieve a recycling report by ID' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'The recycling report with the specified ID.',
    }),
    (0, swagger_1.ApiResponse)({
        status: 404,
        description: 'The recycling report with the specified ID was not found.',
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], RecyclingReportController.prototype, "findRecyclingReportById", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Update a recycling report by ID' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'The recycling report has been successfully updated.',
    }),
    (0, swagger_1.ApiResponse)({
        status: 400,
        description: 'Bad request. Validation errors or other issues.',
    }),
    (0, swagger_1.ApiResponse)({
        status: 404,
        description: 'The recycling report with the specified ID was not found.',
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_recycling_report_dto_1.UpdateRecyclingReportDto]),
    __metadata("design:returntype", Promise)
], RecyclingReportController.prototype, "updateRecyclingReport", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Delete a recycling report by ID' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'The recycling report has been successfully deleted.',
    }),
    (0, swagger_1.ApiResponse)({
        status: 404,
        description: 'The recycling report with the specified ID was not found.',
    }),
    openapi.ApiResponse({ status: 200 }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], RecyclingReportController.prototype, "deleteRecyclingReport", null);
exports.RecyclingReportController = RecyclingReportController = __decorate([
    (0, swagger_1.ApiTags)('recycling-reports'),
    (0, common_1.Controller)({ path: 'recycling-reports', version: '1' }),
    __metadata("design:paramtypes", [recycling_report_service_1.RecyclingReportService])
], RecyclingReportController);
//# sourceMappingURL=recycling-report.controller.js.map