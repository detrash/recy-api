import { RecyclingReport } from '@prisma/client';
import { PrismaService } from '@/modules/prisma/prisma.service';
import { CreateRecyclingReportDto } from './dtos/create-recycling-report.dto';
import { UpdateRecyclingReportDto } from './dtos/update-recycling-report.dto';
export declare class RecyclingReportService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    private checkUserExists;
    createRecyclingReport(createRecyclingReportDto: CreateRecyclingReportDto): Promise<RecyclingReport>;
    findAllRecyclingReports(): Promise<RecyclingReport[]>;
    findRecyclingReportById(id: string): Promise<RecyclingReport>;
    findRecyclingReportsByUser(userId: string): Promise<RecyclingReport[]>;
    updateRecyclingReport(id: string, updateRecyclingReportDto: UpdateRecyclingReportDto): Promise<RecyclingReport>;
    deleteRecyclingReport(id: string): Promise<RecyclingReport>;
}
