export declare class RecyclingReportModule {
}
