import Web3 from 'web3';
export declare class Web3Service {
    private readonly web3;
    private readonly config;
    constructor(web3: Web3, config: {
        wallet: string;
        privateKey: string;
    });
    balance(): Promise<string>;
    transfer(toWallet: string, value: number): Promise<import("web3").Bytes>;
    owner(): Promise<void | [] | (unknown[] & [])>;
}
