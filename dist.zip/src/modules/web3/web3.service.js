"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Web3Service = void 0;
const common_1 = require("@nestjs/common");
const web3_1 = require("web3");
const detrash_certificate_json_1 = require("./abi/detrash-certificate.json");
let Web3Service = class Web3Service {
    constructor(web3, config) {
        this.web3 = web3;
        this.config = config;
    }
    async balance() {
        const balance = await this.web3.eth.getBalance(this.config.wallet);
        return this.web3.utils.fromWei(balance, 'wei');
    }
    async transfer(toWallet, value) {
        const nonce = await this.web3.eth.getTransactionCount(this.config.wallet, 'latest');
        const transaction = {
            to: toWallet,
            value,
            gas: 21000,
            nonce,
        };
        const signedTx = await this.web3.eth.accounts.signTransaction(transaction, this.config.privateKey);
        const tx = await this.web3.eth.sendSignedTransaction(signedTx.rawTransaction);
        return tx.transactionHash;
    }
    async owner() {
        const contract = new this.web3.eth.Contract(detrash_certificate_json_1.default, process.env.CONTRACT_ADDRESS);
        const owner = await contract.methods.owner().call();
        return owner;
    }
};
exports.Web3Service = Web3Service;
exports.Web3Service = Web3Service = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)('Web3')),
    __param(1, (0, common_1.Inject)('Config')),
    __metadata("design:paramtypes", [web3_1.default, Object])
], Web3Service);
//# sourceMappingURL=web3.service.js.map