export declare class Web3Module {
}
