export declare class CalculatorModule {
}
