"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CalculatorController = void 0;
const openapi = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const emails_1 = require("../../../emails");
const mail_service_1 = require("../mail/mail.service");
const calculator_service_1 = require("./calculator.service");
const dtos_1 = require("./dtos");
let CalculatorController = class CalculatorController {
    constructor(calculatorService, mailService) {
        this.calculatorService = calculatorService;
        this.mailService = mailService;
    }
    async contact(supportDto) {
        await this.calculatorService.saveContactInfo(supportDto);
        const mail = {
            to: supportDto.email,
            from: 'no-reply@app.recy.life',
            subject: 'Contact Information',
            react: (0, emails_1.default)({
                companyType: supportDto.companyType,
                employeesQuantity: supportDto.employeesQuantity,
                wasteFootPrint: supportDto.wasteFootPrint,
            }),
        };
        try {
            const { data, error } = await this.mailService.sendEmail(mail);
            if (error) {
                return { message: 'Failed to send email', error };
            }
            return { message: 'Email sent successfully', data };
        }
        catch (error) {
            return { message: 'Failed to send email', error };
        }
    }
    async result(resultDto) {
        await this.calculatorService.saveResultInfo(resultDto);
        return { message: 'Result saved successfully' };
    }
};
exports.CalculatorController = CalculatorController;
__decorate([
    (0, common_1.Post)('contact'),
    (0, swagger_1.ApiOperation)({
        summary: 'Request support',
        description: 'Returns contact information',
    }),
    (0, swagger_1.ApiBody)({ type: dtos_1.SupportDto }),
    (0, swagger_1.ApiOkResponse)({
        description: 'Returns created email response',
    }),
    openapi.ApiResponse({ status: 201, type: Object }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [dtos_1.SupportDto]),
    __metadata("design:returntype", Promise)
], CalculatorController.prototype, "contact", null);
__decorate([
    (0, common_1.Post)('result'),
    (0, swagger_1.ApiOperation)({
        summary: 'Save result',
        description: 'Save result of the calculator',
    }),
    (0, swagger_1.ApiBody)({ type: dtos_1.ResultDto }),
    openapi.ApiResponse({ status: 201 }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [dtos_1.ResultDto]),
    __metadata("design:returntype", Promise)
], CalculatorController.prototype, "result", null);
exports.CalculatorController = CalculatorController = __decorate([
    (0, swagger_1.ApiTags)('calculator'),
    (0, common_1.Controller)({ path: 'calculator', version: '1' }),
    __metadata("design:paramtypes", [calculator_service_1.CalculatorService,
        mail_service_1.MailService])
], CalculatorController);
//# sourceMappingURL=calculator.controller.js.map