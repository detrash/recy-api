import { ResultDto, SupportDto } from './dtos';
export declare class CalculatorService {
    saveContactInfo(infos: SupportDto): void;
    saveResultInfo(info: ResultDto): void;
}
