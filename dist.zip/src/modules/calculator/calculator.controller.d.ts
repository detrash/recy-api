import { MailService } from '@/modules/mail/mail.service';
import { CalculatorService } from './calculator.service';
import { ResultDto, SupportDto } from './dtos';
export declare class CalculatorController {
    private readonly calculatorService;
    private readonly mailService;
    constructor(calculatorService: CalculatorService, mailService: MailService);
    contact(supportDto: SupportDto): Promise<{
        message: string;
        data: import("resend").CreateEmailResponseSuccess;
        error?: undefined;
    } | {
        message: string;
        error: any;
        data?: undefined;
    }>;
    result(resultDto: ResultDto): Promise<{
        message: string;
    }>;
}
