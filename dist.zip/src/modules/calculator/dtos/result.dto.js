"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResultDto = void 0;
const openapi = require("@nestjs/swagger");
class ResultDto {
    static _OPENAPI_METADATA_FACTORY() {
        return { walletAddress: { required: true, type: () => String }, cRecys: { required: true, type: () => Number }, wasteFootprint: { required: true, type: () => Number } };
    }
}
exports.ResultDto = ResultDto;
//# sourceMappingURL=result.dto.js.map