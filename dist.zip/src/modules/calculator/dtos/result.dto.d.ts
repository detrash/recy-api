export declare class ResultDto {
    walletAddress: string;
    cRecys: number;
    wasteFootprint: number;
}
