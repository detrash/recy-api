export declare class SupportDto {
    email: string;
    companyType: string;
    employeesQuantity: number;
    wasteFootPrint: number;
}
