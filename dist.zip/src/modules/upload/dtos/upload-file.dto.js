"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadFileDto = void 0;
const openapi = require("@nestjs/swagger");
class UploadFileDto {
    static _OPENAPI_METADATA_FACTORY() {
        return { fileName: { required: true, type: () => String }, file: { required: true, type: () => Object }, bucketName: { required: true, type: () => String } };
    }
}
exports.UploadFileDto = UploadFileDto;
//# sourceMappingURL=upload-file.dto.js.map