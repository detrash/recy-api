import { ConfigService } from '@nestjs/config';
import { UploadFileDto } from './dtos/upload-file.dto';
export declare class UploadService {
    private readonly configService;
    private readonly s3Client;
    constructor(configService: ConfigService);
    upload({ fileName, file, bucketName }: UploadFileDto): Promise<void>;
}
