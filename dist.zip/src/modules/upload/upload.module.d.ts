export declare class UploadModule {
}
