import { Audit } from '@prisma/client';
import { AuditService } from './audit.service';
import { CreateAuditDto } from './dtos/create-audit.dto';
import { UpdateAuditDto } from './dtos/update-audit.dto';
export declare class AuditController {
    private readonly auditService;
    constructor(auditService: AuditService);
    create(createAuditDto: CreateAuditDto): Promise<Audit>;
    findAll(): Promise<Audit[]>;
    owner(): Promise<void | [] | (unknown[] & [])>;
    findOne(id: string): Promise<Audit>;
    update(id: string, updateAuditDto: UpdateAuditDto): Promise<Audit>;
    remove(id: string): Promise<Audit>;
}
