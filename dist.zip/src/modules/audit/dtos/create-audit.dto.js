"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateAuditSchema = void 0;
const openapi = require("@nestjs/swagger");
const zod_1 = require("zod");
exports.CreateAuditSchema = zod_1.z.object({
    reportId: zod_1.z.string().min(1, { message: 'reportId cannot be empty' }),
    audited: zod_1.z.boolean(),
    auditorId: zod_1.z.string().min(1, { message: 'reportId cannot be empty' }),
    comments: zod_1.z.string().optional(),
});
//# sourceMappingURL=create-audit.dto.js.map