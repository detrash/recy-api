"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateAuditSchema = void 0;
const openapi = require("@nestjs/swagger");
const zod_1 = require("zod");
exports.UpdateAuditSchema = zod_1.z.object({
    audited: zod_1.z.boolean().optional(),
    comments: zod_1.z.string().optional().nullable(),
});
//# sourceMappingURL=update-audit.dto.js.map