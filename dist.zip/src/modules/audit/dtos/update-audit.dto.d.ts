import { z } from 'zod';
export declare const UpdateAuditSchema: z.ZodObject<{
    audited: z.ZodOptional<z.ZodBoolean>;
    comments: z.ZodNullable<z.ZodOptional<z.ZodString>>;
}, "strip", z.ZodTypeAny, {
    audited?: boolean;
    comments?: string;
}, {
    audited?: boolean;
    comments?: string;
}>;
export type UpdateAuditDto = z.infer<typeof UpdateAuditSchema>;
