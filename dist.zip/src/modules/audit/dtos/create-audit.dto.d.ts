import { z } from 'zod';
export declare const CreateAuditSchema: z.ZodObject<{
    reportId: z.ZodString;
    audited: z.ZodBoolean;
    auditorId: z.ZodString;
    comments: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    reportId?: string;
    audited?: boolean;
    auditorId?: string;
    comments?: string;
}, {
    reportId?: string;
    audited?: boolean;
    auditorId?: string;
    comments?: string;
}>;
export type CreateAuditDto = z.infer<typeof CreateAuditSchema>;
