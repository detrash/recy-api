import { Audit } from '@prisma/client';
import { PrismaService } from '@/modules/prisma/prisma.service';
import { Web3Service } from '../web3/web3.service';
import { CreateAuditDto } from './dtos/create-audit.dto';
import { UpdateAuditDto } from './dtos/update-audit.dto';
export declare class AuditService {
    private readonly prisma;
    private readonly web3Service;
    constructor(prisma: PrismaService, web3Service: Web3Service);
    createAudit(createAuditDto: CreateAuditDto): Promise<Audit>;
    findAllAudits(): Promise<Audit[]>;
    findAuditById(id: string): Promise<Audit | null>;
    updateAudit(id: string, updateAuditDto: UpdateAuditDto): Promise<Audit>;
    deleteAudit(id: string): Promise<Audit>;
    owner(): Promise<void | [] | (unknown[] & [])>;
}
