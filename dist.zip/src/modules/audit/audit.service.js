"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const ulid_1 = require("ulid");
const prisma_service_1 = require("../prisma/prisma.service");
const web3_service_1 = require("../web3/web3.service");
let AuditService = class AuditService {
    constructor(prisma, web3Service) {
        this.prisma = prisma;
        this.web3Service = web3Service;
    }
    async createAudit(createAuditDto) {
        var _a, _b;
        const { reportId, audited, auditorId, comments } = createAuditDto;
        try {
            const recyclingReport = await this.prisma.recyclingReport.findUnique({
                where: { id: reportId },
            });
            if (!recyclingReport) {
                throw new common_1.NotFoundException(`RecyclingReport with ID ${reportId} not found.`);
            }
            const auditId = (0, ulid_1.ulid)();
            const audit = await this.prisma.audit.create({
                data: {
                    id: auditId,
                    reportId: reportId,
                    audited,
                    auditorId: auditorId,
                    comments,
                },
            });
            await this.prisma.recyclingReport.update({
                where: { id: reportId },
                data: {
                    audited,
                },
            });
            return audit;
        }
        catch (error) {
            if (error instanceof client_1.Prisma.PrismaClientKnownRequestError) {
                if (error.code === 'P2003') {
                    throw new common_1.BadRequestException(`Foreign key constraint failed on the field: ${(_a = error.meta) === null || _a === void 0 ? void 0 : _a.field_name}`);
                }
                if (error.code === 'P2002') {
                    throw new common_1.BadRequestException(`Unique constraint failed on the field: ${(_b = error.meta) === null || _b === void 0 ? void 0 : _b.target}`);
                }
            }
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.InternalServerErrorException('An unexpected error occurred.');
        }
    }
    async findAllAudits() {
        return this.prisma.audit.findMany();
    }
    async findAuditById(id) {
        return this.prisma.audit.findUnique({ where: { id } });
    }
    async updateAudit(id, updateAuditDto) {
        const existingAudit = await this.prisma.audit.findUnique({ where: { id } });
        if (!existingAudit) {
            throw new common_1.NotFoundException(`Audit with ID ${id} not found.`);
        }
        return this.prisma.audit.update({
            where: { id },
            data: updateAuditDto,
        });
    }
    async deleteAudit(id) {
        const audit = await this.prisma.audit.findUnique({ where: { id } });
        if (!audit) {
            throw new common_1.NotFoundException(`Audit with ID ${id} not found.`);
        }
        return this.prisma.audit.delete({
            where: { id },
        });
    }
    async owner() {
        return this.web3Service.owner();
    }
};
exports.AuditService = AuditService;
exports.AuditService = AuditService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        web3_service_1.Web3Service])
], AuditService);
//# sourceMappingURL=audit.service.js.map