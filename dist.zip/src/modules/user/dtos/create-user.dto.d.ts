export declare class CreateUserDto {
    email: string;
    name: string;
    phone?: string;
    walletAddress?: string;
    roleIds: string[];
}
