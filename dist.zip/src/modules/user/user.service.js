"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const common_1 = require("@nestjs/common");
const ulid_1 = require("ulid");
const prisma_service_1 = require("../prisma/prisma.service");
let UserService = class UserService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    async createUser(createUserDto) {
        const { email, name, phone, walletAddress, roleIds } = createUserDto;
        const existingUser = await this.prisma.user.findUnique({
            where: { email },
        });
        if (existingUser) {
            throw new common_1.ConflictException(`User with email ${email} already exists.`);
        }
        const roles = await this.prisma.role.findMany({
            where: { id: { in: roleIds } },
        });
        const hasAdminRole = roles.some((role) => role.name === 'admin');
        if (hasAdminRole) {
            throw new common_1.ForbiddenException('You are not allowed to assign the "admin" role.');
        }
        const hasWasteGeneratorRole = roles.some((role) => role.name === 'Waste Generator');
        const hasPartnerRole = roles.some((role) => role.name === 'Partner');
        const hasAuditorRole = roles.some((role) => role.name === 'Auditor');
        if ((hasWasteGeneratorRole || hasPartnerRole) && !hasAuditorRole) {
            throw new common_1.ForbiddenException('Waste Generators or Partners can only be assigned the "Auditor" role in addition to their main role.');
        }
        if (hasAuditorRole && !(hasWasteGeneratorRole || hasPartnerRole)) {
            throw new common_1.ForbiddenException('Only Waste Generators or Partners can be assigned the "Auditor" role.');
        }
        const userId = (0, ulid_1.ulid)();
        const user = await this.prisma.user.create({
            data: {
                id: userId,
                email,
                name,
                phone,
                walletAddress,
                userRoles: {
                    create: roleIds.map((roleId) => ({
                        role: { connect: { id: roleId } },
                    })),
                },
            },
            include: { userRoles: { include: { role: true } } },
        });
        return user;
    }
    async updateUser(id, updateUserDto) {
        const existingUser = await this.prisma.user.findUnique({
            where: { id },
        });
        if (!existingUser) {
            throw new common_1.NotFoundException(`User with ID ${id} not found.`);
        }
        const { roleIds } = updateUserDto, updateData = __rest(updateUserDto, ["roleIds"]);
        const roles = await this.prisma.role.findMany({
            where: { id: { in: roleIds } },
        });
        const hasAdminRole = roles.some((role) => role.name === 'admin');
        if (hasAdminRole) {
            throw new common_1.ForbiddenException('You are not allowed to assign the "admin" role.');
        }
        const hasWasteGeneratorRole = roles.some((role) => role.name === 'Waste Generator');
        const hasPartnerRole = roles.some((role) => role.name === 'Partner');
        const hasAuditorRole = roles.some((role) => role.name === 'Auditor');
        if ((hasWasteGeneratorRole || hasPartnerRole) && !hasAuditorRole) {
            throw new common_1.ForbiddenException('Waste Generators or Partners can only be assigned the "Auditor" role in addition to their main role.');
        }
        if (hasAuditorRole && !(hasWasteGeneratorRole || hasPartnerRole)) {
            throw new common_1.ForbiddenException('Only Waste Generators or Partners can be assigned the "Auditor" role.');
        }
        const updatedUser = await this.prisma.user.update({
            where: { id },
            data: Object.assign(Object.assign({}, updateData), { userRoles: {
                    deleteMany: {},
                    create: roleIds.map((roleId) => ({
                        role: { connect: { id: roleId } },
                    })),
                } }),
            include: { userRoles: { include: { role: true } } },
        });
        return updatedUser;
    }
    async deleteUser(id) {
        const existingUser = await this.prisma.user.findUnique({
            where: { id },
        });
        if (!existingUser) {
            throw new common_1.NotFoundException(`User with ID ${id} not found.`);
        }
        return this.prisma.user.delete({
            where: { id },
            include: { userRoles: { include: { role: true } } },
        });
    }
    async findUserByEmail(email) {
        const user = await this.prisma.user.findUnique({
            where: { email },
            include: {
                userRoles: { include: { role: true } },
                audits: true,
                recyclingReports: true,
            },
        });
        if (!user) {
            throw new common_1.NotFoundException(`User with email ${email} not found.`);
        }
        return user;
    }
    async findUserById(id) {
        const user = await this.prisma.user.findUnique({
            where: { id },
            include: {
                userRoles: { include: { role: true } },
                audits: true,
                recyclingReports: true,
            },
        });
        if (!user) {
            throw new common_1.NotFoundException(`User with ID ${id} not found.`);
        }
        return user;
    }
    async findAllUsers() {
        const users = await this.prisma.user.findMany({
            include: {
                userRoles: { include: { role: true } },
                audits: true,
                recyclingReports: true,
            },
        });
        return users;
    }
};
exports.UserService = UserService;
exports.UserService = UserService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], UserService);
//# sourceMappingURL=user.service.js.map