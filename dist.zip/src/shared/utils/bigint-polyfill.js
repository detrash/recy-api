BigInt.prototype.toJSON = function () {
    return this.toString();
};
//# sourceMappingURL=bigint-polyfill.js.map